### CSS Start

放E盘根目录下

![1](.assest/README/1.png)

导入项目

![4](.assest/README/4.png)

![5](.assest/README/5.png)

选仿真器和芯片

![2](.assest/README/2.png)

成功连接至芯片

![3](.assest/README/3.png)

从左往右：debug（调试），flash（烧录），build（编译）

![6](.assest/README/6.png)

### VS Code

① 添加环境变量

![7](.assest/README/7.png)

![8](.assest/README/8.png)

```
E:\TI\ccs1230\xdctools_3_62_01_16_core
XDCTOOLS_JAVA_HOME=E:\ti\ccs1230\ccs\eclipse\jre
```

② 添加 .vscode/c_cpp_properties.json

```json
{
    "configurations": [
        {
            "name": "1",
            "includePath": [
                "E:/DSP8233x_ProjectExample/DSP2833x_Libraries/DSP2833x_common/include",
                "E:/DSP8233x_ProjectExample/DSP2833x_Libraries/DSP2833x_headers/include",
                "E:/TI/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include",
                "${workspaceFolder}/**"
            ],
            "defines": []
        }
    ],
    "version": 4
}
```

添加至 includePath

![9](.assest/README/9.png)

添加至 defines

![10](.assest/README/10.png)

`${workspaceFolder}/**`：搜索子目录

③ 编译 & 清除

```shell
$ cd ./Debug
$ gmake -k all 
$ gmake -k clean
```

-k, --keep-going            Keep going when some targets can't be made.



