/**********************************************************************
* File: Main_9.c -- Solution File for Lab 9
* Devices: TMS320F2833x
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   07/15/08 - original
**********************************************************************/

#include "Lab.h"						// Main include file

//--- Global Variables
Uint16 DEBUG_TOGGLE = 1;				// Used in realtime mode investigation - Lab 6
Uint16 DEBUG_FILTER = 1;				// Used to turn filter on/off - Lab 12

_iq AdcBuf[ADC_BUF_LEN];				// ADC data buffer allocation
_iq AdcBufFiltered[ADC_BUF_LEN];		// ADC filtered data buffer allocation
_iq xDelay[FILTER_LEN] = {0,0,0,0,0};	// filter delay chain
_iq coeffs[FILTER_LEN] = {_IQ(0.0625),_IQ(0.25),_IQ(0.375),_IQ(0.25),_IQ(0.0625)};	// filter coefficients

Uint32 PwmDuty;							// measured PWM duty cycle
Uint32 PwmPeriod;						// measured PWM period

long	GlobalQ = GLOBAL_Q;				// IQmath debug support

#pragma DATA_SECTION(AdcBufRaw, "dmaMemBufs");
Uint16 AdcBufRaw[2*ADC_BUF_LEN];			// ADC raw data buffer allocation


/**********************************************************************
* Function: main()
*
* Description: Main function for C28x workshop labs
**********************************************************************/
void main(void)
{
//--- CPU Initialization
	InitSysCtrl();						// Initialize the CPU (FILE: SysCtrl.c)
	InitGpio();							// Initialize the shared GPIO pins (FILE: Gpio.c)
	InitPieCtrl();						// Initialize and enable the PIE (FILE: PieCtrl.c)
	InitWatchdog();						// Initialize the Watchdog Timer (FILE: WatchDog.c)

//--- Peripheral Initialization
	InitAdc();							// Initialize the ADC (FILE: Adc.c)
	InitEPwm();							// Initialize the EPwm (FILE: EPwm.c) 
	InitECap();							// Initialize the ECap (FILE: ECap.c) 
	InitDma();							// Initialize the DMA (FILE: Dma.c)

//--- Enable global interrupts
	asm(" CLRC INTM, DBGM");			// Enable global interrupts and realtime debug

//--- Main Loop
	while(1)							// endless loop - wait for an interrupt
	{
		asm(" NOP");
	}


} //end of main()


/*** end of file *****************************************************/
