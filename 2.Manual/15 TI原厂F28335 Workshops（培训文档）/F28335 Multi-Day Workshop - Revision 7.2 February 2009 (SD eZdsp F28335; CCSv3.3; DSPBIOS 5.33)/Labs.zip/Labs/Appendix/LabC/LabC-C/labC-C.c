/********************************************************************
            Lab C: Sum-of-Products in C

            Files:    labC-C.c          the main program
                      lab.cmd           linker command file
                      rts2800_ml.lib    run-time support lib

********************************************************************/

/*         Global Variables                        */

/*      initialized table array                    */
#pragma DATA_SECTION(table,"const")
        int table[] = {1,2,3,4,8,6,4,2,0};

/*      uninitialized data arrays                  */
#pragma DATA_SECTION(data,"vars");
        int data[4];
#pragma DATA_SECTION(result,"vars");
        int result;


void main (void)
{















}                          /* end of main */
