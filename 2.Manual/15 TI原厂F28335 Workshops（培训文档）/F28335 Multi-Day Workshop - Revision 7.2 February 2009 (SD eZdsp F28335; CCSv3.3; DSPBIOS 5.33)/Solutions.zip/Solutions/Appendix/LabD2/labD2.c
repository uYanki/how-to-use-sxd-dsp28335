/********************************************************************
            LabD2: C Programming

            Files:    labD2.c           the main program
                      lab.cmd           linker command file
                      sop-c.c           sum of products in C
                      sop-asm.asm       sum of products in assembly
                      rts2800_ml.lib    run-time support lib
********************************************************************/

//initialized global variables
#pragma DATA_SECTION(table,"const")
        int table[] = {1,2,3,4,8,6,4,2,0};

//uninitialized global variables
#pragma DATA_SECTION(data,"vars");
        int data[4];
#pragma DATA_SECTION(result,"vars");
        int result;

//function prototypes
extern int sop(int * , int * , int);


void main(void)
{
//local variables
    int i, n=4;
    int *coeffs;

//copy the table values to the data array
    for(i=0; i<n; i++) data[i] = table[i];

//setup the pointer to the coeff array
    coeffs = table+n;

//call the sum of products routine
    result = sop(data, coeffs, n);

//trap end of main    
    while(1)
    {
        asm(" NOP");
    }

} //end of main
