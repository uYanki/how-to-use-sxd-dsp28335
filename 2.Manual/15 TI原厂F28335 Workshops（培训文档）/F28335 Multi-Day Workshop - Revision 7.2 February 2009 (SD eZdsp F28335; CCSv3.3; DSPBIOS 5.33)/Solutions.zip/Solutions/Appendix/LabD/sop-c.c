/****************************************************************************
            LabD: sop-c.c     sum of products subroutine
****************************************************************************/


int sop(int *indata, int *coeffs, int n)
{
//local variables
    int i, sum=0;

//do the sum of products
    for(i=0; i<n; i++)  sum += indata[i] * coeffs[i];

//return the result
    return sum;

} //end of sop()
