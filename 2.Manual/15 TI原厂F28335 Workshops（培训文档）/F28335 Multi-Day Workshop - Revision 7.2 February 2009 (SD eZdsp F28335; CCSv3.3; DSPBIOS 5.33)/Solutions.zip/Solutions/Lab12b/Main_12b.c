/**********************************************************************
* File: Main_12b.c -- Solution File for Lab 12b
* Devices: TMS320F2833x
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   07/15/08 - original
**********************************************************************/

#include "DSP2833x_Device.h"			// Peripheral address definitions
#include "Lab.h"						// Main include file

//--- Global Variables
Uint16 DEBUG_TOGGLE = 1;				// Used in realtime mode investigation - Lab 6
Uint16 DEBUG_FILTER = 1;				// Used to turn filter on/off - Lab 12

_iq AdcBuf[ADC_BUF_LEN];				// ADC data buffer allocation
_iq AdcBufFiltered[ADC_BUF_LEN];		// ADC filtered data buffer allocation
_iq xDelay[FILTER_LEN] = {0,0,0,0,0};	// filter delay chain
_iq coeffs[FILTER_LEN] = {_IQ(0.0625),_IQ(0.25),_IQ(0.375),_IQ(0.25),_IQ(0.0625)};	// filter coefficients

Uint32 PwmDuty;							// measured PWM duty cycle
Uint32 PwmPeriod;						// measured PWM period

long	GlobalQ = GLOBAL_Q;				// IQmath debug support

#pragma DATA_SECTION(AdcBufRaw, "dmaMemBufs");
Uint16 AdcBufRaw[2*ADC_BUF_LEN];			// ADC raw data buffer allocation


/**********************************************************************
* Function: main()
*
* Description: Main function for C28x workshop labs
**********************************************************************/
void main(void)
{
//--- CPU Initialization
	InitSysCtrl();						// Initialize the CPU (FILE: SysCtrl.c)
	InitGpio();							// Initialize the shared GPIO pins (FILE: Gpio.c)
	InitPieCtrl();						// Initialize and enable the PIE (FILE: PieCtrl.c)
	InitWatchdog();						// Initialize the Watchdog Timer (FILE: WatchDog.c)

//--- Peripheral Initialization
	InitAdc();							// Initialize the ADC (FILE: Adc.c)
	InitEPwm();							// Initialize the EPwm (FILE: EPwm.c) 
	InitECap();							// Initialize the ECap (FILE: ECap.c) 
	InitDma();							// Initialize the DMA (FILE: Dma.c)

//--- Enable global interrupts
									// DSP/BIOS will enable global interrupts (INTM and DBGM)

//--- Main Loop
									// while() loop removed to enable DSP/BIOS


} //end of main()



/**********************************************************************
* Function: LedBlink()
*
* Description: Blinks LED on eZdsp F28335 board
**********************************************************************/
void LedBlink(void)
{
static Uint16 LedSwiCount=0;					// Used for LOG_printf example

//--- Show an example of using LOG_printf() to write to a log buffer
	LOG_printf(&trace, "LedSwiCount = %u", LedSwiCount++);

	GpioDataRegs.GPBTOGGLE.bit.GPIO32 = 1;		// Toggle the pin

} // end of LedBlink()



/**********************************************************************
* Function: AdcSwi()
*
* Description: ADC interrupt SWI
**********************************************************************/
void AdcSwi(void)
{
static _iq *AdcBufPtr = AdcBuf;					// Pointer to ADC data buffer
static _iq *AdcBufFilteredPtr = AdcBufFiltered;	// Pointer to ADC filtered data buffer

//--- Manage the ADC registers
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;			// Reset SEQ1 to CONV00 state
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;			// Clear ADC SEQ1 interrupt flag

//--- Read the ADC result:
	// For IQmath:
	// 1) typecast the unsigned 16-bit result to 32-bit _iq
	// 2) convert from IQ12 to IQ format
	// 3) scale by ADC full-scale range
	//  example:  *AdcBufPtr = _IQmpy(_IQ(3.0), _IQ12toIQ((_iq)AdcMirror.ADCRESULT0));
	//
	// For Float math:
	// 1) typecast the unsigned 16-bit result to 32-bit float.  Gives value from 0 to 4095.
	// 2) scale by 1/4096 to get a value from 0 to ~1
	// 3) scale by ADC full-scale range
	//  example:  *AdcBufPtr = (3.0/4096.0)*(float)AdcMirror.ADCRESULT0;

		*AdcBufPtr = _IQmpy(ADC_FS_VOLTAGE, _IQ12toIQ((_iq)AdcMirror.ADCRESULT0));	// Handles IQmath and float

//--- Call the filter function
	if(DEBUG_FILTER == 1)
	{
		xDelay[0] = *AdcBufPtr++;					// Add the new entry to the delay chain
		*AdcBufFilteredPtr++ = _IQssfir(xDelay, coeffs, FILTER_LEN);
	}
	else
	{
		*AdcBufFilteredPtr++ = *AdcBufPtr++;		// Bypass the filter
	}

//--- Brute-force the circular buffer
	if( AdcBufPtr == (AdcBuf + ADC_BUF_LEN) )
	{
		AdcBufPtr = AdcBuf;						// Rewind the pointer to the beginning
		AdcBufFilteredPtr = AdcBufFiltered;		// Rewind the pointer to the beginning
	}

} // end of AdcSwi()



/**********************************************************************
* Function: Dma1Swi()
*
* Description: DMA Ch1 interrupt SWI
**********************************************************************/
void Dma1Swi(void)
{
static Uint16 iPingPong = 0;					// Ping Pong flag
Uint16 *AdcBufRawPtr;							// Pointer to ADC raw data buffer
_iq *AdcBufPtr = AdcBuf;						// Pointer to ADC data buffer
_iq *AdcBufFilteredPtr = AdcBufFiltered;		// Pointer to ADC filtered data buffer
Uint16 i;										// General purpose Uint16

//--- Process the ADC data
	if(iPingPong == 0)	// Ping buffer filling, process Pong bugger
	{
		// Manage the DMA registers
		asm(" EALLOW");														// Enable EALLOW protected register access
		DmaRegs.CH1.DST_ADDR_SHADOW = (Uint32)AdcBufRaw + ADC_BUF_LEN;		// Adjust DST start address for Pong buffer
		asm(" EDIS");														// Disable EALLOW protected register access

		// Initialization the raw data buffer pointer
		AdcBufRawPtr = AdcBufRaw + ADC_BUF_LEN;		// Point to Pong buffer

		// Scale and filter the raw ADC data
		for(i=0; i<ADC_BUF_LEN; i++)
		{
			//--- Read the ADC result:
			// For IQmath:
			// 1) typecast the unsigned 16-bit result to 32-bit _iq
			// 2) convert from IQ12 to IQ format
			// 3) scale by ADC full-scale range
			//  example:  *AdcBufPtr = _IQmpy(_IQ(3.0), _IQ12toIQ((_iq)AdcMirror.ADCRESULT0));
			//
			// For Float math:
			// 1) typecast the unsigned 16-bit result to 32-bit float.  Gives value from 0 to 4095.
			// 2) scale by 1/4096 to get a value from 0 to ~1
			// 3) scale by ADC full-scale range
			//  example:  *AdcBufPtr = (3.0/4096.0)*(float)AdcMirror.ADCRESULT0;

			*AdcBufPtr = _IQmpy(ADC_FS_VOLTAGE, _IQ12toIQ((_iq)*AdcBufRawPtr++));	// Handles IQmath and float

			//--- Call the filter function
			if(DEBUG_FILTER == 1)
			{
				xDelay[0] = *AdcBufPtr++;					// Add the new entry to the delay chain
				*AdcBufFilteredPtr++ = _IQssfir(xDelay, coeffs, FILTER_LEN);
			}
			else
			{
				*AdcBufFilteredPtr++ = *AdcBufPtr++;		// Bypass the filter
			}
		}
	}
	else				// Pong buffer filling, process Ping buffer
	{
		// Manage the DMA registers
		asm(" EALLOW");														// Enable EALLOW protected register access
		DmaRegs.CH1.DST_ADDR_SHADOW = (Uint32)AdcBufRaw;					// Adjust DST start address for Ping buffer
		asm(" EDIS");														// Disable EALLOW protected register access

		// Initialization the raw data buffer pointer
		AdcBufRawPtr = AdcBufRaw;					// Point to Ping buffer

		// Scale and filter the raw ADC data
		for(i=0; i<ADC_BUF_LEN; i++)
		{
			//--- Read the ADC result:
			// For IQmath:
			// 1) typecast the unsigned 16-bit result to 32-bit _iq
			// 2) convert from IQ12 to IQ format
			// 3) scale by ADC full-scale range
			//  example:  *AdcBufPtr = _IQmpy(_IQ(3.0), _IQ12toIQ((_iq)AdcMirror.ADCRESULT0));
			//
			// For Float math:
			// 1) typecast the unsigned 16-bit result to 32-bit float.  Gives value from 0 to 4095.
			// 2) scale by 1/4096 to get a value from 0 to ~1
			// 3) scale by ADC full-scale range
			//  example:  *AdcBufPtr = (3.0/4096.0)*(float)AdcMirror.ADCRESULT0;

			*AdcBufPtr = _IQmpy(ADC_FS_VOLTAGE, _IQ12toIQ((_iq)*AdcBufRawPtr++));	// Handles IQmath and float

			//--- Call the filter function
			if(DEBUG_FILTER == 1)
			{
				xDelay[0] = *AdcBufPtr++;					// Add the new entry to the delay chain
				*AdcBufFilteredPtr++ = _IQssfir(xDelay, coeffs, FILTER_LEN);
			}
			else
			{
				*AdcBufFilteredPtr++ = *AdcBufPtr++;		// Bypass the filter
			}
		}
	}

//--- Update the Ping Pong buffer flag
	iPingPong ^= 1;								// iPingPong toggles between 0 and 1

} // end of Dma1Swi()



/*** end of file *****************************************************/
